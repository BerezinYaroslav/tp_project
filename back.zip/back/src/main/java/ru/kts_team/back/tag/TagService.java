package ru.kts_team.back.tag;

import ru.kts_team.back.task.Task;

import java.util.List;

/**
 * @author yaroslavberezin
 * @created 29/05/2024
 * @project tp_project
 */
public interface TagService {
    void addTag(Tag tag);

    List<Tag> getTags();

    Tag getTagById(Long id);

    void updateTag(Tag tag);

    void deleteTags();

    void deleteTagById(Long id);
}
