package ru.kts_team.back.list;

import java.util.List;

/**
 * @author yaroslavberezin
 * @created 29/05/2024
 * @project tp_project
 */
public interface TaskListService {
    void addList(TaskList taskList);

    List<TaskList> getLists();

    TaskList getListById(Long id);

    void updateList(TaskList taskList);

    void deleteLists();

    void deleteListById(Long id);
}
