package ru.kts_team.back.user;

import ru.kts_team.back.task.Task;

import java.util.List;

/**
 * @author yaroslavberezin
 * @created 29/05/2024
 * @project tp_project
 */
public interface UserService {
    void addUser(User user);

    List<User> getUsers();

    User getUserById(Long id);

    void updateUser(User user);

    void deleteUsers();

    void deleteUserById(Long id);
}
